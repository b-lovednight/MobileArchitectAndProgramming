package com.zybooks.eventtrackingapp;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class EventDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "events.db";
    private static final int VERSION = 1;

    public EventDatabase(MainActivity context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class EventTable {
        // Declaration of Primary Key Column, Table Name, and other Columns
        private static final String TABLE = "events";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "event_name";
        private static final String COL_EVENT_DATE = "event_date";
        private static final String COL_EVENT_OWNER = "event_owner";
        private static final String COL_EVENT_INVITEE = "event_invitee";
        private static final String COL_EVENT_START = "event_start";
        private static final String COL_EVENT_END = "event_end";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Table
        String createTable = "CREATE TABLE " + EventTable.TABLE + " (" + EventTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + EventTable.COL_NAME + " TEXT, " + EventTable.COL_EVENT_DATE + " TEXT, " + EventTable.COL_EVENT_OWNER + " TEXT, " + EventTable.COL_EVENT_INVITEE + " TEXT, " + EventTable.COL_EVENT_START + " TEXT, " + EventTable.COL_EVENT_END + " TEXT)";
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + EventTable.TABLE);
        onCreate(db);
    }
}
