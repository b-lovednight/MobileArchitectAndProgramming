package com.zybooks.eventtrackingapp;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "logins.db";
    private static final int VERSION = 1;

    public LoginDatabase(LoginActivity context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class LoginTable {
        private static final String TABLE = "logins";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // db.execSQL("create table " + LoginTable.TABLE + " (" + LoginTable.COL_ID + " integer primary key autoincrement, " + LoginTable.COL_USERNAME + " text, " + LoginTable.COL_PASSWORD + "text");
        // Create Table
        String createTable = "CREATE TABLE " + LoginTable.TABLE + " (" + LoginTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + LoginTable.COL_USERNAME + " TEXT UNIQUE, " + LoginTable.COL_PASSWORD + " TEXT)";
        db.execSQL(createTable);

        // Insert Admin User
        String insertAdminUser = "INSERT INTO " + LoginTable.TABLE + " (" + LoginTable.COL_USERNAME + ", " + LoginTable.COL_PASSWORD + ") VALUES ('admin', 'admin')";
        db.execSQL(insertAdminUser);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }
}
