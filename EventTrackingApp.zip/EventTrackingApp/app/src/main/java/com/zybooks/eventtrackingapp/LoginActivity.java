package com.zybooks.eventtrackingapp;

import com.zybooks.eventtrackingapp.LoginDatabase;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

public class LoginActivity extends AppCompatActivity {

    private LoginDatabase dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new LoginDatabase(this);
        // Pulling data from XML View
        EditText userName = findViewById(R.id.userName);
        EditText passWord = findViewById(R.id.passWord);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonRegister = findViewById(R.id.buttonRegister);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernameInput = userName.getText().toString();
                String passwordInput = passWord.getText().toString();

                if (usernameInput.isEmpty() || passwordInput.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                    return;
                }
                // Check for successful username and password sign in
                if (checkUserCredentials(usernameInput, passwordInput)) {
                    Toast.makeText(LoginActivity.this, "Success!", Toast.LENGTH_SHORT).show();
                    // On successful sign in, create new intent and move to different MainActivity Java class
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    // Check if username already exists
                    if (checkUsername(usernameInput)) {
                        Toast.makeText(LoginActivity.this, "Username exists, check password", Toast.LENGTH_SHORT).show();
                    } else {
                        // Function registerUser() is boolean so IF it is TRUE, THEN inform user of success
                        if (registerUser(usernameInput, passwordInput)) {
                            Toast.makeText(LoginActivity.this, "New user added!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(LoginActivity.this, "Failed to add user!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        }); // buttonLogin end

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(LoginActivity.this, "Register button clicked", Toast.LENGTH_SHORT).show();
            }
        }); // buttonRegister end
    }

    private boolean checkUserCredentials(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] columns = {"_id"};
        String selection = "username = ? AND password = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query("logins", columns, selection, selectionArgs, null, null, null);

        boolean userExists = cursor.getCount() > 0;

        cursor.close();
        db.close();

        return userExists;
    }

    private boolean checkUsername(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] columns = {"_id"};
        String selection = "username = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query("logins", columns, selection, selectionArgs, null, null, null);

        // Function getCount will be 1 if username is found
        boolean usernameFound = cursor.getCount() > 0;

        // Close database and cursor function read
        cursor.close();
        db.close();

        return usernameFound;
    }

    private boolean registerUser(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert("logins", null, values);

        return result != -1;
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
